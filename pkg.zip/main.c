// Starting point
// docs link: https://github.com/jart/cosmopolitan

int main (void) {

}
