# cosmoTemplate 
## Basic template code for [Cosmopolitan LibC](https://justine.lol/cosmopolitan/index.html) projects 
